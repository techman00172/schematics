# pyright: strict

from pygls.server import LanguageServer
from lsprotocol.types import (
    Diagnostic,
    DiagnosticSeverity,
    Position,
    Range,
    DidOpenTextDocumentParams,
    CompletionItem,
    CompletionList,
    CompletionParams,
    InsertTextFormat,
    CompletionItemKind,
    MarkupKind,
    MarkupContent
)
import logging
import sqlite3
import os

# Set up logging to file
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='/tmp/mecrisp.lsp.log',
    filemode='w'
)
logger = logging.getLogger(__name__)

logger.info("=== LANGUAGE SERVER STARTING ===")

class MCUCompletionProvider:
    def __init__(self, db_path: str ="mecrisp_stellaris.db"):
        self.db_path = db_path
        logger.info(f"Initializing completion provider with database: {db_path}")
        self._ensure_database_exists()

    def _ensure_database_exists(self):
        if not os.path.exists(self.db_path):
            logger.warning(f"Database {self.db_path} not found. Creating with sample data...")
            self._create_sample_database()
        else:
            logger.info(f"Database {self.db_path} exists")

    def _create_sample_database(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        cursor.execute('''
            CREATE TABLE FORTH(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                word TEXT UNIQUE NOT NULL,
                stack TEXT,
                description TEXT,
                example TEXT
            )
        ''')

        sample_data = [
            ("emit?", "( -- flag )", "Ready to send a character ?", "emit? ."),
            ("key?", "( -- flag )", "Checks if a key is waiting", "key? IF .\" Key!\" THEN"),
            ("key", "( -- char )", "Waits for and fetches the pressed key", "key emit"),
            ("emit", "( char -- )", "Emits a character", "65 emit"),
            ("hook-emit?", "( -- a-addr )", "Hooks for redirecting", "' hook-emit? @ ."),
            ("hook-key?", "( -- a-addr )", "terminal IO", "' hook-key? @ ."),
            ("hook-key", "( -- a-addr )", "on the fly", "' hook-key @ ."),
            ("hook-emit", "( -- a-addr )", "", "' hook-emit @ ."),
            ("serial-emit?", "( -- flag )", "Serial interface", "serial-emit? ."),
            ("serial-key?", "( -- flag )", "terminal routines", "serial-key? ."),
            ("serial-key", "( -- char )", "as default communications", "serial-key emit"),
            ("serial-emit", "( char -- )", "", "65 serial-emit"),
            ("hook-pause", "( -- a-addr )", "Hook for a multitasker", "' hook-pause @ ."),
            ("pause", "( -- )", "Task switch, none for default", "pause"),
        ]

        cursor.executemany(
            "INSERT INTO FORTH (word, stack, description, example) VALUES (?, ?, ?, ?)",
            sample_data
        )
        conn.commit()
        conn.close()
        logger.info("Created sample database with FORTH table")

    def get_all_completions(self):
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute(
                "SELECT word, stack, description, example FROM FORTH ORDER BY word"
            )
            results = cursor.fetchall()
            conn.close()
            logger.info(f"Loaded {len(results)} completions from database {self.db_path}")
            return results
        except sqlite3.Error as e:
            logger.error(f"Database error: {e}")
            return []

    def search_completions(self, prefix=""):
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            query = "SELECT word, stack, description, example FROM FORTH"
            params = []

            if prefix:
                escaped_prefix = (
                    prefix.replace("\\", "\\\\")
                          .replace("%", "\\%")
                          .replace("_", "\\_")
                )
                query += " WHERE word LIKE ? ESCAPE '\\'"
                params.append(f"{escaped_prefix}%")

            query += " ORDER BY word"
            cursor.execute(query, params)
            results = cursor.fetchall()
            conn.close()
            logger.info(f"Search for '{prefix}': found {len(results)} results")
            return results
        except sqlite3.Error as e:
            logger.error(f"Database error: {e}")
            return []

completion_provider = MCUCompletionProvider()
json_server = LanguageServer("mecrisp.lsp", "v0.1")

@json_server.feature("textDocument/didOpen")
def did_open(ls: LanguageServer, params: DidOpenTextDocumentParams):
    logger.info("=== DOCUMENT OPENED ===")
    ls.show_message("Text Document Did Open")
    text_doc = ls.workspace.get_document(params.text_document.uri)
    ls.publish_diagnostics(text_doc.uri, [])

@json_server.feature("textDocument/completion")
def completion(ls: LanguageServer, params: CompletionParams):
    logger.info("=== COMPLETION REQUEST START ===")
    text_doc = ls.workspace.get_document(params.text_document.uri)

    if params.position.line >= len(text_doc.lines):
        return CompletionList(is_incomplete=False, items=[])

    current_line = text_doc.lines[params.position.line]
    char_pos = min(params.position.character, len(current_line))

    word_start = char_pos
    while word_start > 0:
        prev_char = current_line[word_start - 1]
        if not (prev_char.isalnum() or prev_char in {'_', '>'}):
            break
        word_start -= 1

    current_word = current_line[word_start:char_pos]

    if current_word:
        results = completion_provider.search_completions(prefix=current_word)
    else:
        results = completion_provider.get_all_completions()

    items = []
    for word, stack, description, example in results:
        doc_parts = []
        if stack:
            doc_parts.append(f"**Stack:** `{stack}`")
        if description:
            doc_parts.append(f"**Description:** {description}")
        if example:
            doc_parts.append(f"**Example:** `{example}`")
        documentation_md = "\n\n".join(doc_parts)

        completion_item = CompletionItem(
            label=word,
            kind=CompletionItemKind.Function,
            detail="",  # <- suppresses RHS label in Helix
            documentation=MarkupContent(
                kind=MarkupKind.Markdown,
                value=documentation_md
            ),
            insert_text=word,
            insert_text_format=InsertTextFormat.PlainText,
            sort_text=word,
            filter_text=word
        )
        items.append(completion_item)

    logger.info(f"Returning {len(items)} completion items")
    logger.info("=== COMPLETION REQUEST END ===")
    return CompletionList(is_incomplete=False, items=items)

if __name__ == "__main__":
    logger.info("Starting language server...")
    json_server.start_io()

# // SPDX-License-Identifier: MIT

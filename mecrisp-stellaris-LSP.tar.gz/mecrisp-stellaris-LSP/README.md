![](assets/logo.svg)


> An [LSP](https://langserver.org/) implementation for [mecrisp-stellaris](https://mecrisp-stellaris-folkdoc.sourceforge.io/) embedded Forth development, providing syntax highlighting, code navigation, and diagnostics in your favorite editor.



---

## Key Features

- 📱 **Editor Integration**: Developed with [Helix](https://helix-editor.com). Should work with VS Code, and any LSP-compatible editor but only tested on Helix.
- ⚡ **Performance**: SQLite-backed for consistent, fast responses

---

## Installation & Usage

```bash
# Clone the repository (Fossil SCM)
fossil clone https://chiselapp.com/user/tp/repository/mecrisp-stellaris-lsp

# Install dependencies
pip install pygls

# Start the language server
python3 mecrisp_stellaris_lsp.py
```

**Editor Configuration**:
1. For Helix: See the language.toml example in the 'helix-editor' sub directory.

---

## Example Usage


![Language Server Example](assets/screenshot.png)

```forth
\ STM32F4 LED control example
: LED-ON  ( -- )  0x40020000 1 B! ; \ Enable blue LED

: MAIN  ( -- )
    LED-ON
    1000 MS  \ Wait 1 second
    LED-OFF
;

 1 8 ls⚡
```

The language server provides:
- completion of 'lshift' with an example
---

## Dependencies

| Component | Version  |
|-----------|----------|
| Python    | 3.9+     |
| pygls     | 1.3.1+   |
| SQLite    | 3.0+     |

---

## Contribute

We welcome contributions! See:[CONTRIBUTING](contributing.md) for guidelines.

**License**: [MIT](LICENSE)

---

*Developed by [Terry Porter](https://mecrisp-stellaris-folkdoc.sourceforge.io/)*
```


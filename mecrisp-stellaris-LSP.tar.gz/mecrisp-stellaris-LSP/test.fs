: leds ( -- )
  %01 8 2* lshift
  %01 9 2* lshift or PORTC_MODER bis! \ set PC8 and PC9 as output
  begin
    button? if ld3on ld4off else ld3off ld4on then
  key? until \ loop until reset or keyboard key pressed
  ld3off ld4off
;

  1 8 lshift
  abs
  compiletoram?
  compare
  
